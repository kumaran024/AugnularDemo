import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username = ''
  password = ''
  invalidLogin = false
  constructor(private router: Router,
    private loginservice: AuthenticationService) { }

    ngOnInit() {
    document.getElementById("lgut").style.visibility = "hidden";
  }

  getUserName(){
    this.loginservice.getData(this.username).subscribe(
      ( data: Response ) => {
          console.log ( 'Data response: ', data);
      },
      ( error ) => {
          console.log ( 'Error: ' + error);
      }
  );
  }
  checkLogin() {
    if (this.loginservice.authenticate(this.username, this.password)
    ) {
      this.router.navigate([''])
      this.getUserName();
      this.invalidLogin = false
    } else {
      if((this.username) && (this.password)){
        var x = document.getElementById("snackbar");
        x.className = "show";
        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
        }
      this.invalidLogin = true
    }
  }
  // let subject = new Subject<string>();
// We subscribe to the subject
// subject.subscribe((data) => {
//   console.log("Subscriber got data >>>>> "+ data);
// });

// We use the subject to emit data
//subject.next("Eureka");
 
}
