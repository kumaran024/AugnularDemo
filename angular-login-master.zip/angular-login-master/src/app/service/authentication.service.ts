import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  public myData: string;
  constructor() { }
// Behavior subjects need a first value
  getData(username) {
  let subject = new BehaviorSubject<string>(username);
  subject.next(username);
  console.log("Name :"+username);
  return username;
  }
    authenticate(username, password) {
    if (((username === "1596888") || (username === "1596892") || (username === "1516807"))  && password === "password") {
      sessionStorage.setItem('username', username)
      return true;
    } else {
      return false;
    }
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    console.log(!(user === null))
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
  }
}