import { Component, Input, OnInit } from '@angular/core';
import { HttpClientService, Employee } from '../service/httpclient.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  
  public usrName: string;
 
  employees:Employee[];
  
  constructor(private router: Router,
    private httpClientService:HttpClientService
  ) { 
    
  }

  // processInput(): void {
  //   if(this.usrName === "1596888")
  //   {
  //     this.usrName = "vijayakumar".toUpperCase();
  //   }
  // }

  ngOnInit() {
     this.httpClientService.getEmployees().subscribe(
      response =>this.handleSuccessfulResponse(response),
     );
  }

handleSuccessfulResponse(response)
{
    this.employees=response;
}

deleteEmployee(employee: Employee): void {
   this.httpClientService.deleteEmployee(employee)
     .subscribe( data => {
      this.employees = this.employees.filter(u => u !== employee);
   })
};
dashboardPage() {
    this.router.navigate(['dashboard'])
  }
  executionPage() {

  }
}